let currentJob = null;
let jobGrades = [];
let employees = [];
let nearbyPlayers = [];
let searchTimeout = null;
let recruitmentDistance = 5; // Default value

window.addEventListener('message', function(event) {
    if (event.data.type === 'openPanel') {
        currentJob = event.data.job;
        document.getElementById('currentJobLabel').textContent = event.data.jobLabel;
        recruitmentDistance = event.data.recruitmentDistance;
        document.getElementById('recruitmentDistance').textContent = recruitmentDistance;
        document.getElementById('app').classList.remove('hidden');
        refreshPanel();
    }
});

function closePanel() {
    document.getElementById('app').classList.add('hidden');
    fetch(`https://${GetParentResourceName()}/closePanel`, {
        method: 'POST',
        body: JSON.stringify({})
    });
}

function refreshPanel() {
    fetch(`https://${GetParentResourceName()}/getAccountMoney`, {
        method: 'POST',
        body: JSON.stringify({
            job: currentJob
        })
    })
    .then(resp => resp.json())
    .then(balance => {
        document.getElementById('balance').textContent = `${balance.toLocaleString()} SEK`;
    });

    fetch(`https://${GetParentResourceName()}/getJobGrades`, {
        method: 'POST',
        body: JSON.stringify({
            job: currentJob
        })
    })
    .then(resp => resp.json())
    .then(grades => {
        jobGrades = Array.isArray(grades) ? grades : [];
        renderSalaryManagement();
    });

    fetch(`https://${GetParentResourceName()}/getEmployees`, {
        method: 'POST',
        body: JSON.stringify({
            job: currentJob
        })
    })
    .then(resp => resp.json())
    .then(data => {
        employees = Array.isArray(data) ? data : [];
        renderEmployees();
    });

    fetch(`https://${GetParentResourceName()}/getNearbyPlayers`, {
        method: 'POST',
        body: JSON.stringify({})
    })
    .then(resp => resp.json())
    .then(players => {
        nearbyPlayers = Array.isArray(players) ? players : [];
        renderNearbyPlayers();
    });
}

function renderEmployees() {
    const sortBy = document.getElementById('sortBy').value;
    if (!Array.isArray(employees)) {
        employees = [];
    }

    const sortedEmployees = [...employees].sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return `${a.firstname} ${a.lastname}`.localeCompare(`${b.firstname} ${b.lastname}`);
            case 'rank':
                return a.job_grade - b.job_grade;
            case 'salary':
                return a.salary - b.salary;
            default:
                return 0;
        }
    });

    const container = document.getElementById('employees');
    container.innerHTML = '';
    
    sortedEmployees.forEach(employee => {
        const rankOptions = Array.isArray(jobGrades) ? jobGrades.map(grade => 
            `<option value="${grade.grade}" ${employee.job_grade == grade.grade ? 'selected' : ''}>
                ${grade.label || grade.name || `Grad ${grade.grade}` || 'Okänd'}
            </option>`
        ).join('') : '';

        const card = document.createElement('div');
        card.className = 'employee-card';
        card.innerHTML = `
            <div class="employee-info">
                <h3>${employee.firstname} ${employee.lastname}</h3>
                <p>Rang: 
                    <select class="rank-select" onchange="updateEmployeeRank('${employee.identifier}', this.value)">
                        ${rankOptions}
                    </select>
                </p>
                <p>Lön: ${employee.salary.toLocaleString()} SEK</p>
            </div>
            <div class="employee-actions">
                <button class="btn btn-danger" onclick="fireEmployee('${employee.identifier}')">Avskeda</button>
            </div>
        `;
        container.appendChild(card);
    });
}

function renderSalaryManagement() {
    const container = document.getElementById('rankSalaries');
    container.innerHTML = '';

    jobGrades.forEach(grade => {
        const row = document.createElement('div');
        row.className = 'rank-salary-row';
        row.innerHTML = `
            <div>
                <strong>${grade.label}</strong>
            </div>
            <div>
                <input type="number" class="salary-input" value="${grade.salary}"
                    onchange="updateGradeSalary(${grade.grade}, this.value)">
            </div>
        `;
        container.appendChild(row);
    });
}

function fireEmployee(identifier) {
    fetch(`https://${GetParentResourceName()}/fireEmployee`, {
        method: 'POST',
        body: JSON.stringify({
            identifier: identifier
        })
    })
    .then(() => {
        refreshPanel();
    });
}

function updateEmployeeRank(identifier, grade) {
    fetch(`https://${GetParentResourceName()}/updateEmployeeRank`, {
        method: 'POST',
        body: JSON.stringify({
            identifier: identifier,
            grade: grade
        })
    })
    .then(() => {
        refreshPanel();
    });
}

function updateGradeSalary(grade, salary) {
    fetch(`https://${GetParentResourceName()}/updateEmployeeSalary`, {
        method: 'POST',
        body: JSON.stringify({
            grade: grade,
            salary: salary
        })
    })
    .then(() => {
        refreshPanel();
    });
}

function depositMoney() {
    const amount = document.getElementById('depositAmount').value;
    if (!amount || amount <= 0) {
        return;
    }

    fetch(`https://${GetParentResourceName()}/depositMoney`, {
        method: 'POST',
        body: JSON.stringify({
            amount: parseInt(amount)
        })
    })
    .then(() => {
        document.getElementById('depositAmount').value = '';
        refreshPanel();
    });
}

function withdrawMoney() {
    const amount = document.getElementById('withdrawAmount').value;
    if (!amount || amount <= 0) {
        return;
    }

    fetch(`https://${GetParentResourceName()}/withdrawMoney`, {
        method: 'POST',
        body: JSON.stringify({
            amount: parseInt(amount)
        })
    })
    .then(() => {
        document.getElementById('withdrawAmount').value = '';
        refreshPanel();
    });
}

document.addEventListener('keyup', function(event) {
    if (event.key === 'Escape') {
        closePanel();
    }
});

document.getElementById('sortBy').addEventListener('change', renderEmployees);

function renderNearbyPlayers() {
    const container = document.getElementById('nearbyPlayers');
    const searchTerm = document.getElementById('playerSearch').value.toLowerCase();
    container.innerHTML = '';

    const filteredPlayers = nearbyPlayers.filter(player => 
        player.name.toLowerCase().includes(searchTerm)
    );

    if (filteredPlayers.length === 0) {
        container.innerHTML = '<div class="no-players">Inga spelare i närheten</div>';
        return;
    }

    filteredPlayers.forEach(player => {
        const card = document.createElement('div');
        card.className = 'player-card';
        card.innerHTML = `
            <div class="player-info">
                <div class="player-name">
                    ${player.name}
                    <span class="distance-tag">${player.distance}m</span>
                </div>
                <div class="current-job">Nuvarande jobb: ${player.job_label}</div>
            </div>
            <button class="btn btn-recruit" onclick="recruitPlayer('${player.identifier}')">
                Rekrytera
            </button>
        `;
        container.appendChild(card);
    });
}

function recruitPlayer(identifier) {
    fetch(`https://${GetParentResourceName()}/recruitPlayer`, {
        method: 'POST',
        body: JSON.stringify({
            identifier: identifier
        })
    })
    .then(() => {
        refreshPanel();
    });
}

document.getElementById('playerSearch').addEventListener('input', function(e) {
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    }
    searchTimeout = setTimeout(() => {
        renderNearbyPlayers();
    }, 300);
});

function openBilling() {
    fetch(`https://${GetParentResourceName()}/openBilling`, {
        method: 'POST',
        body: JSON.stringify({})
    });
    closePanel();
}