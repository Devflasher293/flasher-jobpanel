Config = {}

Config.AllowedJobs = {
    'police',
    'ambulance',
    'mecano',
    'cardealer',
    'qpark',
    'scstyling',
    'archeologist'
}

Config.RequiredGrade = {
    ['police'] = 3,     
    ['ambulance'] = 3,  
    ['mecano'] = 4,   
    ['cardealer'] = 2,   
    ['qpark'] = 0,   
    ['scstyling'] = 3,
    ['archeologist'] = 2
}

Config.Commands = {
    openPanel = 'jobpanel'
}

Config.RecruitmentDistance = 5.0

Config.Labels = {
    managementPanel = 'Företagspanel',
    societyBalance = 'Företagskonto',
    deposit = 'Sätt in',
    withdraw = 'Ta ut',
    depositAmount = 'Belopp att sätta in',
    withdrawAmount = 'Belopp att ta ut',
    sortBy = {
        name = 'Sortera efter namn',
        rank = 'Sortera efter rang',
        salary = 'Sortera efter lön'
    },
    recruitment = {
        title = 'Rekrytering',
        distance = 'Spelare måste vara inom %sm för att rekryteras',
        searchPlayers = 'Sök efter spelare...',
        noPlayers = 'Inga spelare i närheten',
        currentJob = 'Nuvarande jobb: %s',
        recruitButton = 'Rekrytera'
    },
    employees = {
        rank = 'Rang',
        salary = 'Lön',
        fireButton = 'Avskeda'
    },
    salaryManagement = {
        title = 'Lönehantering'
    }
} 