ESX = exports["es_extended"]:getSharedObject()

ESX.RegisterServerCallback('job_panel:getEmployees', function(source, cb, jobName)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return cb({}) end
    
    if xPlayer.job.name ~= jobName or xPlayer.job.grade < Config.RequiredGrade[jobName] then
        return cb({})
    end

    MySQL.Async.fetchAll('SELECT DISTINCT u.identifier, u.firstname, u.lastname, u.job, u.job_grade, ' ..
        'j.label as job_label, ' ..
        'COALESCE(jg.label, "Unknown") as grade_label, ' ..
        'COALESCE(jg.name, "unknown") as grade_name, ' ..
        'jg.salary ' ..
        'FROM users u ' ..
        'JOIN jobs j ON j.name = u.job ' ..
        'LEFT JOIN job_grades jg ON jg.job_name = u.job AND jg.grade = u.job_grade ' ..
        'WHERE u.job = @job OR u.identifier = @identifier', {
        ['@job'] = jobName,
        ['@identifier'] = xPlayer.identifier
    }, function(employees)
        cb(employees or {})
    end)
end)

ESX.RegisterServerCallback('job_panel:getAccountMoney', function(source, cb, jobName)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer or xPlayer.job.name ~= jobName or xPlayer.job.grade < Config.RequiredGrade[jobName] then
        return cb(0)
    end

    local society = 'society_' .. jobName
    
    TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
        if account then
            cb(account.money)
        else
            print('^1[job_panel] Society account not found: ' .. society .. '^7')
            cb(0)
        end
    end)
end)

RegisterNetEvent('job_panel:fireEmployee')
AddEventHandler('job_panel:fireEmployee', function(targetIdentifier)
    local xPlayer = ESX.GetPlayerFromId(source)
    local xTarget = ESX.GetPlayerFromIdentifier(targetIdentifier)
    
    if not xPlayer or xPlayer.job.grade < Config.RequiredGrade[xPlayer.job.name] then
        return
    end

    MySQL.Async.execute('UPDATE users SET job = "unemployed", job_grade = 0 WHERE identifier = @identifier', {
        ['@identifier'] = targetIdentifier
    })

    if xTarget then
        xTarget.setJob('unemployed', 0)
        TriggerClientEvent('esx:showNotification', xTarget.source, 'Du har blivit avskedad!')
    end
end)

ESX.RegisterServerCallback('job_panel:getJobGrades', function(source, cb, jobName)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer or xPlayer.job.name ~= jobName or xPlayer.job.grade < Config.RequiredGrade[jobName] then
        return cb(false)
    end

    MySQL.Async.fetchAll('SELECT grade, name, label, salary FROM job_grades WHERE job_name = @job ORDER BY grade ASC', {
        ['@job'] = jobName
    }, function(grades)
        cb(grades)
    end)
end)

RegisterNetEvent('job_panel:updateEmployeeRank')
AddEventHandler('job_panel:updateEmployeeRank', function(targetIdentifier, newGrade)
    local xPlayer = ESX.GetPlayerFromId(source)
    local xTarget = ESX.GetPlayerFromIdentifier(targetIdentifier)
    
    if not xPlayer or xPlayer.job.grade < Config.RequiredGrade[xPlayer.job.name] then
        return
    end

    local newGradeNum = tonumber(newGrade)
    local playerGrade = tonumber(xPlayer.job.grade)

    if not newGradeNum or not playerGrade then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Ogiltig grad!')
        return
    end

    if newGradeNum >= playerGrade then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Du kan inte befordra till denna grad!')
        return
    end

    MySQL.Async.execute('UPDATE users SET job_grade = @grade WHERE identifier = @identifier AND job = @job', {
        ['@grade'] = newGradeNum,
        ['@identifier'] = targetIdentifier,
        ['@job'] = xPlayer.job.name
    })

    if xTarget then
        xTarget.setJob(xPlayer.job.name, newGradeNum)
        TriggerClientEvent('esx:showNotification', xTarget.source, 'Din grad har uppdaterats!')
    end
end)

RegisterNetEvent('job_panel:updateEmployeeSalary')
AddEventHandler('job_panel:updateEmployeeSalary', function(gradeId, newSalary)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer or xPlayer.job.grade < Config.RequiredGrade[xPlayer.job.name] then
        return
    end

    local salaryAmount = tonumber(newSalary)
    if not salaryAmount then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Ogiltig lön!')
        return
    end

    if salaryAmount < 0 or salaryAmount > 100000 then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Lönen måste vara mellan 0-100,000 SEK!')
        return
    end

    MySQL.Async.fetchAll('SELECT 1 FROM job_grades WHERE job_name = @job AND grade = @grade', {
        ['@job'] = xPlayer.job.name,
        ['@grade'] = gradeId
    }, function(result)
        if result and result[1] then
            MySQL.Async.execute('UPDATE job_grades SET salary = @salary WHERE job_name = @job AND grade = @grade', {
                ['@salary'] = salaryAmount,
                ['@job'] = xPlayer.job.name,
                ['@grade'] = gradeId
            })
        end
    end)
end)

local transactionCooldowns = {}
local COOLDOWN_TIME = 2000 -- 2 seconds cooldown

RegisterNetEvent('job_panel:depositMoney')
AddEventHandler('job_panel:depositMoney', function(amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer or xPlayer.job.grade < Config.RequiredGrade[xPlayer.job.name] then
        return
    end

    amount = tonumber(amount)
    if not amount or amount <= 0 then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Ogiltigt belopp!')
        return
    end

    if xPlayer.getMoney() < amount then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Inte tillräckligt med pengar!')
        return
    end

    local society = 'society_' .. xPlayer.job.name
    
    TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
        if account then
            xPlayer.removeMoney(amount)
            account.addMoney(amount)
            TriggerClientEvent('esx:showNotification', xPlayer.source, 'Satte in ' .. amount .. ' SEK')
        else
            print('^1[job_panel] Failed to deposit money. Society account not found: ' .. society .. '^7')
            TriggerClientEvent('esx:showNotification', xPlayer.source, 'Företagskonto hittades inte!')
        end
    end)
end)

RegisterNetEvent('job_panel:withdrawMoney')
AddEventHandler('job_panel:withdrawMoney', function(amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer or xPlayer.job.grade < Config.RequiredGrade[xPlayer.job.name] then
        return
    end

    local lastTransaction = transactionCooldowns[source] or 0
    local currentTime = GetGameTimer()
    if currentTime - lastTransaction < COOLDOWN_TIME then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Vänta lite innan du gör en ny transaktion!')
        return
    end
    transactionCooldowns[source] = currentTime

    amount = tonumber(amount)
    if not amount or amount <= 0 then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Ogiltigt belopp!')
        return
    end

    if amount > 1000000 then -- 1 million limit
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Transaktionen är för stor!')
        return
    end

    TriggerEvent('esx_society:getSociety', xPlayer.job.name, function(society)
        if not society then
            TriggerClientEvent('esx:showNotification', xPlayer.source, 'Företagskonto hittades inte!')
            return
        end

        TriggerEvent('esx_addonaccount:getSharedAccount', society.account, function(account)
            if not account then
                TriggerClientEvent('esx:showNotification', xPlayer.source, 'Företagskonto hittades inte!')
                return
            end

            if account.money >= amount then
                account.removeMoney(amount)
                xPlayer.addMoney(amount)
                TriggerClientEvent('esx:showNotification', xPlayer.source, 'Tog ut ' .. amount .. ' SEK')
            else
                TriggerClientEvent('esx:showNotification', xPlayer.source, 'Inte tillräckligt med pengar i företagskontot!')
            end
        end)
    end)
end)

ESX.RegisterServerCallback('job_panel:getNearbyPlayers', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local players = {}
    
    if not xPlayer or xPlayer.job.grade < Config.RequiredGrade[xPlayer.job.name] then
        return cb({})
    end

    local xPlayers = ESX.GetPlayers()
    local playerCoords = GetEntityCoords(GetPlayerPed(source))
    
    for _, playerId in ipairs(xPlayers) do
        local xTarget = ESX.GetPlayerFromId(playerId)
        if xTarget and xTarget.source ~= source then -- Don't include the recruiter
            local targetCoords = GetEntityCoords(GetPlayerPed(playerId))
            local distance = #(playerCoords - targetCoords)
            
            if distance <= Config.RecruitmentDistance then
                table.insert(players, {
                    source = xTarget.source,
                    identifier = xTarget.identifier,
                    name = xTarget.getName(),
                    job = xTarget.job.name,
                    job_label = xTarget.job.label,
                    distance = math.floor(distance)
                })
            end
        end
    end
    
    cb(players)
end)

RegisterNetEvent('job_panel:recruitPlayer')
AddEventHandler('job_panel:recruitPlayer', function(targetIdentifier)
    local xPlayer = ESX.GetPlayerFromId(source)
    local xTarget = ESX.GetPlayerFromIdentifier(targetIdentifier)
    
    if not xPlayer or xPlayer.job.grade < Config.RequiredGrade[xPlayer.job.name] then
        return
    end

    if not xTarget then
        TriggerClientEvent('esx:showNotification', xPlayer.source, 'Spelare hittades inte!')
        return
    end

    xTarget.setJob(xPlayer.job.name, 0)
    TriggerClientEvent('esx:showNotification', xTarget.source, 'Du har blivit rekryterad som ' .. xPlayer.job.label)
    TriggerClientEvent('esx:showNotification', xPlayer.source, 'Rekryterade ' .. xTarget.getName())
end)

AddEventHandler('playerDropped', function()
    transactionCooldowns[source] = nil
end)

CreateThread(function()
    Wait(1000) -- Wait for other resources to initialize
    for _, job in ipairs(Config.AllowedJobs) do
        local society = 'society_' .. job
        TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
            if not account then
                print('^1[job_panel] WARNING: Society account not found: ' .. society .. '^7')
            else
                print('^2[job_panel] Society account loaded: ' .. society .. '^7')
            end
        end)
    end
end)