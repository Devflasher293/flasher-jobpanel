ESX = exports["es_extended"]:getSharedObject()

exports('OpenJobPanel', function()
    local playerData = ESX.GetPlayerData()
    
    if not playerData.job then return end
    
    if Config.RequiredGrade[playerData.job.name] and playerData.job.grade >= Config.RequiredGrade[playerData.job.name] then
        OpenJobPanel()
    else
        ESX.ShowNotification('Du har inte behörighet att öppna företagspanelen')
    end
end)

RegisterNetEvent('job_panel:openMenu')
AddEventHandler('job_panel:openMenu', function()
    local playerData = ESX.GetPlayerData()
    
    if not playerData.job then return end
    
    if Config.RequiredGrade[playerData.job.name] and playerData.job.grade >= Config.RequiredGrade[playerData.job.name] then
        OpenJobPanel()
    else
        ESX.ShowNotification('Du har inte behörighet att öppna företagspanelen')
    end
end)

RegisterCommand(Config.Commands.openPanel, function()
    local playerData = ESX.GetPlayerData()
    
    if not playerData.job then return end
    
    if Config.RequiredGrade[playerData.job.name] and playerData.job.grade >= Config.RequiredGrade[playerData.job.name] then
        OpenJobPanel()
    else
        ESX.ShowNotification('Du har inte behörighet att öppna företagspanelen')
    end
end)

function OpenJobPanel()
    local playerData = ESX.GetPlayerData()
    local jobLabel = playerData.job.label

    SetNuiFocus(true, true)
    SendNUIMessage({
        type = 'openPanel',
        job = playerData.job.name,
        jobLabel = jobLabel,
        recruitmentDistance = Config.RecruitmentDistance
    })
end 